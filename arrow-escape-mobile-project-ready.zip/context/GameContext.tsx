import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export interface GameSettings {
  sound: boolean;
  vibration: boolean;
  darkMode: boolean;
}

export interface PersistedGameState {
  coins: number;
  unlockedLevel: number;
  completed: Record<string, number>;
  settings: GameSettings;
  dailyDate: string | null;
  dailyStreak: number;
}

interface GameContextValue {
  state: PersistedGameState;
  hydrated: boolean;
  completeLevel: (levelId: number, stars: number, reward: number) => void;
  claimDailyReward: (today: string) => boolean;
  spendCoins: (amount: number) => boolean;
  toggleSetting: (key: keyof GameSettings) => void;
}

const STORAGE_KEY = 'arrow-escape-progress-v1';
const defaultState: PersistedGameState = {
  coins: 100,
  unlockedLevel: 1,
  completed: {},
  settings: { sound: true, vibration: true, darkMode: false },
  dailyDate: null,
  dailyStreak: 0,
};

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<PersistedGameState>(defaultState);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    void AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!mounted) return;
        if (raw) {
          try {
            setState({ ...defaultState, ...JSON.parse(raw) } as PersistedGameState);
          } catch {
            setState(defaultState);
          }
        }
        setHydrated(true);
      })
      .catch(() => setHydrated(true));
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (hydrated) void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [hydrated, state]);

  const value = useMemo<GameContextValue>(() => ({
    state,
    hydrated,
    completeLevel: (levelId, stars, reward) => {
      setState((current) => {
        const previous = current.completed[String(levelId)] ?? 0;
        const nextCompleted = { ...current.completed, [String(levelId)]: Math.max(previous, stars) };
        return {
          ...current,
          coins: current.coins + reward,
          completed: nextCompleted,
          unlockedLevel: Math.max(current.unlockedLevel, levelId + 1),
        };
      });
    },
    claimDailyReward: (today) => {
      if (state.dailyDate === today) return false;
      setState((current) => {
        if (current.dailyDate === today) return current;
        return { ...current, coins: current.coins + 50, dailyDate: today, dailyStreak: current.dailyStreak + 1 };
      });
      return true;
    },
    spendCoins: (amount) => {
      if (state.coins < amount) return false;
      setState((current) => {
        if (current.coins < amount) return current;
        return { ...current, coins: current.coins - amount };
      });
      return true;
    },
    toggleSetting: (key) => {
      setState((current) => ({ ...current, settings: { ...current.settings, [key]: !current.settings[key] } }));
    },
  }), [hydrated, state]);

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame(): GameContextValue {
  const context = useContext(GameContext);
  if (!context) throw new Error('useGame must be used within GameProvider');
  return context;
}