export type Direction = 'up' | 'right' | 'down' | 'left';
export type Difficulty = 'EASY' | 'NORMAL' | 'HARD' | 'EXPERT' | 'MASTER';

export interface Arrow {
  id: string;
  row: number;
  col: number;
  direction: Direction;
  solutionDirection: Direction;
  rotatable: boolean;
  rotated: boolean;
  locked: boolean;
  dependencyId?: string;
}

export interface Level {
  id: number;
  size: number;
  difficulty: Difficulty;
  arrows: Arrow[];
  solution: string[];
}

export const LEVELS_PER_BATCH = 200;

const DIRECTIONS: Direction[] = ['up', 'right', 'down', 'left'];
const DELTAS: Record<Direction, { row: number; col: number }> = {
  up: { row: -1, col: 0 },
  right: { row: 0, col: 1 },
  down: { row: 1, col: 0 },
  left: { row: 0, col: -1 },
};

const WORLD_NAMES = [
  'First Steps',
  'Direction',
  'Crossroads',
  'Tricky Paths',
  'The Maze',
  'Mind Bender',
  'Chaos',
  'Ultimate Flow',
];

function seededRandom(seed: number): () => number {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let t = value;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function getDifficulty(levelId: number): Difficulty {
  if (levelId <= 25) return 'EASY';
  if (levelId <= 50) return 'NORMAL';
  if (levelId <= 100) return 'HARD';
  if (levelId <= 150) return 'EXPERT';
  return 'MASTER';
}

export function getGridSize(levelId: number): number {
  if (levelId <= 10) return 5;
  if (levelId <= 25) return 6;
  if (levelId <= 50) return 7;
  if (levelId <= 100) return 8;
  return 9;
}

export function getArrowCount(levelId: number, size: number): number {
  const base = levelId <= 25 ? 6 + Math.floor(levelId / 4) : 12 + Math.floor(levelId * 0.26);
  const density = levelId >= 151 ? 0.66 : levelId >= 101 ? 0.56 : levelId >= 51 ? 0.45 : 0.34;
  return Math.min(size * size - 4, Math.max(base, Math.floor(size * size * density)));
}

function pathIsClear(
  row: number,
  col: number,
  direction: Direction,
  arrows: Array<Pick<Arrow, 'row' | 'col'>>,
): boolean {
  const delta = DELTAS[direction];
  let nextRow = row + delta.row;
  let nextCol = col + delta.col;
  while (nextRow >= 0 && nextRow < 20 && nextCol >= 0 && nextCol < 20) {
    if (arrows.some((arrow) => arrow.row === nextRow && arrow.col === nextCol)) return false;
    nextRow += delta.row;
    nextCol += delta.col;
    if ((delta.row !== 0 && (nextRow < 0 || nextRow >= 20)) || (delta.col !== 0 && (nextCol < 0 || nextCol >= 20))) break;
  }
  return true;
}

function pathIsClearOnBoard(
  row: number,
  col: number,
  direction: Direction,
  arrows: Array<Pick<Arrow, 'row' | 'col'>>,
  size: number,
): boolean {
  const delta = DELTAS[direction];
  let nextRow = row + delta.row;
  let nextCol = col + delta.col;
  while (nextRow >= 0 && nextRow < size && nextCol >= 0 && nextCol < size) {
    if (arrows.some((arrow) => arrow.row === nextRow && arrow.col === nextCol)) return false;
    nextRow += delta.row;
    nextCol += delta.col;
  }
  return true;
}

function generateBaseArrows(levelId: number, size: number, count: number): Array<Pick<Arrow, 'row' | 'col' | 'solutionDirection'>> {
  const random = seededRandom(levelId * 7919 + size * 101);
  const built: Array<Pick<Arrow, 'row' | 'col' | 'solutionDirection'>> = [];
  const used = new Set<string>();

  for (let index = count - 1; index >= 0; index -= 1) {
    let placed: Pick<Arrow, 'row' | 'col' | 'solutionDirection'> | undefined;
    for (let attempt = 0; attempt < 6000 && !placed; attempt += 1) {
      const row = Math.floor(random() * size);
      const col = Math.floor(random() * size);
      const direction = DIRECTIONS[Math.floor(random() * DIRECTIONS.length)];
      const key = `${row}:${col}`;
      if (used.has(key)) continue;
      if (!pathIsClearOnBoard(row, col, direction, built, size)) continue;
      placed = { row, col, solutionDirection: direction };
    }

    if (!placed) {
      for (let row = 0; row < size && !placed; row += 1) {
        for (let col = 0; col < size && !placed; col += 1) {
          if (used.has(`${row}:${col}`)) continue;
          for (const direction of DIRECTIONS) {
            if (pathIsClearOnBoard(row, col, direction, built, size)) {
              placed = { row, col, solutionDirection: direction };
              break;
            }
          }
        }
      }
    }

    if (!placed) break;
    built.push(placed);
    used.add(`${placed.row}:${placed.col}`);
  }

  if (built.length === count) return built.reverse();

  // Dense boards can occasionally trap the randomized reverse builder. Use a
  // deterministic, edge-safe ordering so every requested arrow still exists
  // and the level remains solvable.
  const fallbackRandom = seededRandom(levelId * 3571 + size * 43);
  const cells = Array.from({ length: size * size }, (_, index) => ({
    row: Math.floor(index / size),
    col: index % size,
  }));
  for (let index = cells.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(fallbackRandom() * (index + 1));
    [cells[index], cells[swapIndex]] = [cells[swapIndex], cells[index]];
  }
  const direction = DIRECTIONS[levelId % DIRECTIONS.length];
  const selected = cells.slice(0, count).sort((first, second) => {
    if (direction === 'up') return first.row - second.row || first.col - second.col;
    if (direction === 'down') return second.row - first.row || first.col - second.col;
    if (direction === 'left') return first.col - second.col || first.row - second.row;
    return second.col - first.col || first.row - second.row;
  });
  return selected.map((cell) => ({ ...cell, solutionDirection: direction }));
}

export function rotateDirection(direction: Direction, steps: number): Direction {
  const current = DIRECTIONS.indexOf(direction);
  return DIRECTIONS[(current + steps + DIRECTIONS.length * 10) % DIRECTIONS.length];
}

export function createLevel(levelId: number): Level {
  const size = getGridSize(levelId);
  const count = getArrowCount(levelId, size);
  const base = generateBaseArrows(levelId, size, count);
  const difficulty = getDifficulty(levelId);
  const arrows: Arrow[] = base.map((item, index) => {
    const id = `${levelId}-${index}`;
    const rotatable = levelId >= 101 && index % 7 === 3;
    const locked = levelId >= 101 && index > 0 && index % 5 === 2;
    return {
      id,
      row: item.row,
      col: item.col,
      direction: rotatable ? rotateDirection(item.solutionDirection, -1) : item.solutionDirection,
      solutionDirection: item.solutionDirection,
      rotatable,
      rotated: !rotatable,
      locked,
      dependencyId: locked ? `${levelId}-${index - 1}` : undefined,
    };
  });

  return {
    id: levelId,
    size,
    difficulty,
    arrows,
    solution: arrows.map((arrow) => arrow.id),
  };
}

export function cloneArrows(arrows: Arrow[]): Arrow[] {
  return arrows.map((arrow) => ({ ...arrow }));
}

export function isArrowUnlocked(arrow: Arrow, activeArrows: Arrow[]): boolean {
  if (!arrow.locked || !arrow.dependencyId) return true;
  return !activeArrows.some((candidate) => candidate.id === arrow.dependencyId);
}

export function canArrowLeave(arrow: Arrow, activeArrows: Arrow[], size: number): boolean {
  if (!isArrowUnlocked(arrow, activeArrows)) return false;
  if (arrow.rotatable && !arrow.rotated) return false;
  return pathIsClearOnBoard(arrow.row, arrow.col, arrow.direction, activeArrows.filter((candidate) => candidate.id !== arrow.id), size);
}

export function getHintArrow(arrows: Arrow[], size: number): Arrow | undefined {
  return arrows.find((arrow) => isArrowUnlocked(arrow, arrows) && arrow.rotatable && !arrow.rotated)
    ?? arrows.find((arrow) => canArrowLeave(arrow, arrows, size));
}

export function getWorldName(levelId: number): string {
  return WORLD_NAMES[Math.floor((levelId - 1) / 25)] ?? WORLD_NAMES[0];
}

export function getTodayKey(): string {
  const date = new Date();
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}

export function getDailyLevelId(): number {
  const date = new Date();
  const seed = date.getFullYear() * 372 + (date.getMonth() + 1) * 31 + date.getDate();
  return (seed % LEVELS_PER_BATCH) + 1;
}

export function calculateStars(attempts: number, arrowCount: number): number {
  if (attempts <= arrowCount + 2) return 3;
  if (attempts <= Math.ceil(arrowCount * 1.5)) return 2;
  return 1;
}

export function formatStars(stars: number): string {
  return `${stars >= 1 ? '★' : '☆'}${stars >= 2 ? '★' : '☆'}${stars >= 3 ? '★' : '☆'}`;
}

export function getReward(levelId: number): number {
  if (levelId <= 25) return 15;
  if (levelId <= 50) return 20;
  if (levelId <= 100) return 25;
  if (levelId <= 150) return 30;
  return 35;
}

export function validateLevel(level: Level): boolean {
  const active = cloneArrows(level.arrows);
  for (const id of level.solution) {
    const index = active.findIndex((candidate) => candidate.id === id);
    const arrow = index >= 0 ? active[index] : undefined;
    if (!arrow) return false;
    if (arrow.rotatable && !arrow.rotated) {
      active[index] = { ...arrow, rotated: true, direction: arrow.solutionDirection };
    }
    const resolvedArrow = active[index];
    if (!resolvedArrow || !canArrowLeave(resolvedArrow, active, level.size)) return false;
    active.splice(index, 1);
  }
  return active.length === 0;
}

export function getDifficultySubtitle(difficulty: Difficulty): string {
  switch (difficulty) {
    case 'EASY': return 'Learn the flow';
    case 'NORMAL': return 'Read the crossings';
    case 'HARD': return 'Think two moves ahead';
    case 'EXPERT': return 'Dependencies awaken';
    case 'MASTER': return 'Nothing is accidental';
  }
}

export { WORLD_NAMES };