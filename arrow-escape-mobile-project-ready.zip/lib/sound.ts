import { Platform } from 'react-native';
import * as Haptics from 'expo-haptics';

export type SoundName =
  | 'click'
  | 'start'
  | 'exit'
  | 'wrong'
  | 'locked'
  | 'rotate'
  | 'undo'
  | 'restart'
  | 'hint'
  | 'complete'
  | 'gameover'
  | 'unlock'
  | 'daily';

type GainNodeLike = {
  gain: { setValueAtTime: (value: number, time: number) => void; exponentialRampToValueAtTime: (value: number, time: number) => void };
  connect: (...destination: any[]) => unknown;
};

type OscillatorLike = {
  type: string;
  frequency: { setValueAtTime: (value: number, time: number) => void; exponentialRampToValueAtTime: (value: number, time: number) => void };
  connect: (...destination: any[]) => unknown;
  start: (time?: number) => void;
  stop: (time?: number) => void;
};

type AudioContextLike = {
  currentTime: number;
  destination: unknown;
  createOscillator: () => OscillatorLike;
  createGain: () => GainNodeLike;
};

let audioContext: AudioContextLike | null = null;

function getAudioContext(): AudioContextLike | null {
  if (Platform.OS !== 'web') return null;
  const globalWithAudio = globalThis as typeof globalThis & {
    AudioContext?: new () => AudioContextLike;
    webkitAudioContext?: new () => AudioContextLike;
  };
  const Constructor = globalWithAudio.AudioContext ?? globalWithAudio.webkitAudioContext;
  if (!Constructor) return null;
  audioContext ??= new Constructor();
  return audioContext;
}

function tone(frequency: number, duration: number, type: string = 'sine', endFrequency?: number): void {
  const context = getAudioContext();
  if (!context) return;
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  const now = context.currentTime;
  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, now);
  if (endFrequency) oscillator.frequency.exponentialRampToValueAtTime(endFrequency, now + duration);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.16, now + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(now);
  oscillator.stop(now + duration + 0.02);
}

function webSound(name: SoundName): void {
  switch (name) {
    case 'click': tone(460, 0.06, 'triangle', 540); break;
    case 'start': tone(330, 0.1, 'sine', 520); break;
    case 'exit': tone(300, 0.28, 'sine', 680); break;
    case 'wrong': tone(170, 0.16, 'sawtooth', 110); break;
    case 'locked': tone(125, 0.12, 'square', 90); break;
    case 'rotate': tone(360, 0.16, 'triangle', 600); break;
    case 'undo': tone(500, 0.12, 'triangle', 330); break;
    case 'restart': tone(220, 0.12, 'sine', 420); break;
    case 'hint': tone(520, 0.18, 'sine', 760); break;
    case 'complete':
      tone(392, 0.12, 'sine', 460);
      setTimeout(() => tone(523, 0.12, 'sine', 620), 90);
      setTimeout(() => tone(659, 0.22, 'sine', 800), 180);
      break;
    case 'gameover': tone(260, 0.18, 'sawtooth', 140); break;
    case 'unlock': tone(440, 0.1, 'sine', 660); break;
    case 'daily': tone(520, 0.12, 'triangle', 740); break;
  }
}

export function playFeedback(name: SoundName, soundEnabled: boolean, vibrationEnabled: boolean): void {
  if (soundEnabled) webSound(name);
  if (!vibrationEnabled) return;
  if (Platform.OS === 'web') {
    const browser = globalThis as typeof globalThis & { navigator?: { vibrate?: (pattern: number | number[]) => boolean } };
    browser.navigator?.vibrate?.(name === 'wrong' ? [20, 30, 20] : name === 'complete' ? [18, 35, 18] : 12);
    return;
  }
  const impact = name === 'wrong' || name === 'gameover' ? Haptics.ImpactFeedbackStyle.Heavy : name === 'complete' ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light;
  void Haptics.impactAsync(impact);
}